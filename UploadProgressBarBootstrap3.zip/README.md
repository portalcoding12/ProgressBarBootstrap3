## Dokumentasi
<a href="https://www.portalcoding.com/2019/03/upload-file-dengan-progress-bar.html">https://www.portalcoding.com/2019/03/upload-file-dengan-progress-bar.html</a>
